# FlexRadio_Project
This project will take a MCU and check varying number of voltage sources on other PCBs. These will then be output to an array of LEDs
